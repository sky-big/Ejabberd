# Version 0.6.1

* Repository is now forked to p1_oauth2 for consistency (Mickaël Rémond)
* Initial release on Hex.pm (Mickaël Rémond)
* Standard ProcessOne build chain (Mickaël Rémond)
* Setup Travis-CI and test coverage, tests still needed (Mickaël Rémond)
