# Version 1.0.0

* Application is now called iconv for consistency (Mickaël Rémond)
* Initial release on Hex.pm (Mickaël Rémond)
* Standard ProcessOne build chain (Mickaël Rémond)
* Support for Travis-CI and test coverage (Mickaël Rémond)
