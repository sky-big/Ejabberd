# epam

epam for ejabberd to help with PAM authentication support
