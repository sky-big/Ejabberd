# Version 1.0.3

* Fix for compilation on Windows (Paweł Chmielowski)
* Fix typo in error message (Paweł Chmielowski)

# Version 1.0.1

* Use p1_utils v1.0.3 (Mickaël Rémond)
