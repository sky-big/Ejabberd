# Version 1.0.1

* Repository is now called ezlib to reflect module names (Mickaël Rémond)
* Initial release on Hex.pm (Mickaël Rémond)
* Standard ProcessOne build chain (Mickaël Rémond)
* Support for Travis-CI and test coverage (Mickaël Rémond)
