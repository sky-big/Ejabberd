# Version 1.0.2

* Update Fast TLS and Stun (Mickaël Rémond)

# Version 1.0.1

* Repository is now called esip for consistency (Mickaël Rémond)
* Initial release on Hex.pm (Mickaël Rémond)
* Standard ProcessOne build chain (Mickaël Rémond)
* Support for Travis-CI and test coverage (Mickaël Rémond)
