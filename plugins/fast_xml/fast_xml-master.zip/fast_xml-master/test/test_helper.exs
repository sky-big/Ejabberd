ExUnit.start()
# Mix is starting application fast_xml automatically
