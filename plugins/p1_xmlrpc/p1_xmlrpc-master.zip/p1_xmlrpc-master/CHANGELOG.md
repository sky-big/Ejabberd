# Version 1.15.1

* Repository is now forked to p1_xmlrpc for consistency (Mickaël Rémond)
* Initial release on Hex.pm (Mickaël Rémond)
* Standard ProcessOne build chain (Mickaël Rémond)
* Setup Travis-CI and test coverage (Mickaël Rémond)
