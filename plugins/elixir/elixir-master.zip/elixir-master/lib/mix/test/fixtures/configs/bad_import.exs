use Mix.Config

import_config "bad_root.exs"