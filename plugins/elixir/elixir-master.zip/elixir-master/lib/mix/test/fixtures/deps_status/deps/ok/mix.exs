defmodule Ok.Mixfile do
  use Mix.Project

  def project do
    [app: :ok,
     version: "0.1.0"]
  end
end
