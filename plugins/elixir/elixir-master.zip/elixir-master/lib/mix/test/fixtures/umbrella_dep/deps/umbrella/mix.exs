defmodule Umbrella.Mixfile do
  use Mix.Project

  def project do
    [apps_path: "apps"]
  end
end
