# Version 1.0.1

* Update to depend on p1_utils 1.0.3 (Mickaël Rémond)

# Version 1.0.0

* Initial release on Hex.pm (Mickaël Rémond)
* Project is renamed fast_yaml.
* Continuous integration with Travis CI and Coveralls (Mickaël Rémond)
* License changed to Apache v2, so that it can be used in a wide range
  of software.
