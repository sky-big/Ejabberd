# Version 1.0.1

* Use Fast TLS 1.0.1 (Mickaël Rémond)

# Version 1.0.0

* Prepare release on Hex.pm (Mickaël Rémond)
* Rename application to stun instead of p1_stun (Mickaël Rémond)
* Document usage (Evgeny Khramtsov) 
