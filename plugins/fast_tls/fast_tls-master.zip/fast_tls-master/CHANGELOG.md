# Version 1.0.1

* Build improve, remove check on Erlang version for better build chain compliance (Mickaël Rémond)

# Version 1.0.0

* Release on Hex.pm (Mickaël Rémond)
* Project renamed to fast_tls to emphasize on performance (Mickaël
  Rémond)
