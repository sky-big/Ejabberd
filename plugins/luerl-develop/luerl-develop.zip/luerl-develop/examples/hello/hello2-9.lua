-- File    : hello2-9.lua
-- Purpose : Demonstration of Luerl interface.
-- See     : ./examples/hello/hello2.erl

function confirm(p)
	return p .. ' (it really is)'
end

return confirm(a)