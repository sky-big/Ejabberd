-- File    : hello2-3.lua
-- Purpose : Demonstration of Luerl interface.
-- See     : ./examples/hello/hello2.erl

function no() print("(16) No!") end

print("(15) Maybe ...")

return "(X) Yes!"