-- File    : hello2-7.lua
-- Purpose : Demonstration of Luerl interface.
-- See     : ./examples/hello/hello2.erl

a = "(28a) οἶδα οὐκ εἰδώς, oîda ouk eidōs"
return a
