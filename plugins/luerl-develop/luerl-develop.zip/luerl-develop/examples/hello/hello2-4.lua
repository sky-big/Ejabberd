-- File    : hello2-4.lua
-- Purpose : Demonstration of Luerl interface.
-- See     : ./examples/hello/hello2.erl

return "'(18b) Evidently, Mr. Watson.'"