-- File     : hello2-10.lua
-- Purpose  : Returning lua dicts
-- See      : ./examples/hello/hello2.erl

return {1,2,{3,'Hello World!'}}

